package classes

interface HasIdAndName {
    var id: String
    var name: String
}